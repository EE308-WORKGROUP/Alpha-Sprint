from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse

# Create your views here.
def search_view(request, search_something):
    html = search_data(search_something)
    return HttpResponse(html)

def data_view(request):
    html = return_data()
    return HttpResponse(html)

#添加收藏
def favorate_add_view(request, some_favorates):
    html = favorate_pages_add(some_favorates)
    return HttpResponse(html)

#显示收藏
def favorate_view(request):
    html = favorate_pages_return()
    return HttpResponse(html)

#微信端发出请求,python端返回带有title与link的字典
def return_data():
    from arduino.models import Arduino520

    reuslt = []
    links = Arduino520.objects.values('title', 'link')
    num = 0
    for value in links:
        reuslt.append(value)
    #links = Arduino520.objects.filter(title=titles) #查找网站名字对应的link
    del reuslt[0]
    del reuslt[30]
    reuslt.pop()

    return JsonResponse(reuslt, safe=False)

#搜索功能
def search_data(sth):
    from arduino.models import Arduino520
    data = Arduino520.objects.filter(title__contains=sth)
    # results = {}
    # num = 1
    # for one in data:
    #     results['result%s'%num] = str(one)
    #     num += 1
    # #查询到信息
    # if len(data)>= 1:
    #     return JsonResponse(results)
    results = []
    for one in data:
        result = {}
        one = str(one)
        one_split = one.split('_')
        result['title'] = str(one_split[0])
        result['link'] = str(one_split[1])
        results.append(result)
    #查询到信息
    if len(data)>= 1:
        return JsonResponse(results, safe=False)

    #查询失败
    else:

        return '未查询到相关信息'

#收藏功能（添加）
def favorate_pages_add(sths):

    from arduino.models import Arduino520
    #向数据库中插入收藏的数据
    b1 = Arduino520.objects.create(favorate= sths)
    b1.save()
    return b1


#收藏功能（查询并返回）
def favorate_pages_return():

    from arduino.models import Arduino520
    #向数据库中查询收藏的数据
    data = Arduino520.objects.values('favorate')
    return data