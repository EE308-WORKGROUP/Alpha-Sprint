from django.contrib import admin
from .models import Arduino520
# Register your models here.

admin.site.register(Arduino520)