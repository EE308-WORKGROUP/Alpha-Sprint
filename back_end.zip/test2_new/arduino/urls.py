from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [

    path('data', views.data_view),
    path('search/<str:search_something>', views.search_view),
    #path('favorate/<str:some_favorates>', views.favorate_pages_add),
    #path('showfavorate', views.favorate_view)
]