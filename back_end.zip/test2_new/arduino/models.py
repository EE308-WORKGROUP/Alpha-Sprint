from django.db import models

# Create your models here.
class Arduino520(models.Model):
    title = models.TextField(blank=True, null=True)
    link = models.TextField(blank=True, null=True)
    video = models.TextField(blank=True, null=True)


    class Meta:
        managed = True
        db_table = 'Arduino520'

    def __str__(self):
        return '%s_%s_'%(self.title,self.link)