from django.apps import AppConfig


class HigerArduinoConfig(AppConfig):
    name = 'higer_arduino'
