from django.contrib import admin
from .models import Arduino521
# Register your models here.

admin.site.register(Arduino521)