from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [

    path('datahigher', views.datahigher_view),
    path('searchhigher/<str:search_something>', views.searchhigher_view),

]