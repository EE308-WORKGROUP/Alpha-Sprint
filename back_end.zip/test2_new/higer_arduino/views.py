from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse

# Create your views here.
def searchhigher_view(request, search_something):
    html = search_datahigher(search_something)
    return HttpResponse(html)

def datahigher_view(request):
    html = return_datahigher()
    return HttpResponse(html)


#函数

def return_datahigher():
    from higer_arduino.models import Arduino521

    reuslt = []
    links = Arduino521.objects.values('title', 'link')
    for value in links:
        reuslt.append(value)
    #links = Arduino520.objects.filter(title=titles) #查找网站名字对应的link
    reuslt.pop()

    return JsonResponse(reuslt, safe=False)

#搜索功能
def search_datahigher(sth):
    from higer_arduino.models import Arduino521

    data = Arduino521.objects.filter(title__contains=sth)
    results = []
    for one in data:
        result = {}
        one = str(one)
        one_split = one.split('_')
        result['title'] = str(one_split[0])
        result['link'] = str(one_split[1])
        results.append(result)
    #查询到信息
    if len(data)>= 1:
        return JsonResponse(results, safe=False)

    #查询失败
    else:

        return '未查询到相关信息'
